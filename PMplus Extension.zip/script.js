const leftSilde = document.querySelector('.left-slide')
const rightSlide = document.querySelector('.right-slide')
const rightSlide1 = document.querySelector('.right-slide-1')
const checkedToRightButton = document.querySelector('.checked-to-right')
const allToRightButton = document.querySelector('.all-to-right')
const checkedToLeftButton = document.querySelector('.checked-to-left')
const allToLeftButton = document.querySelector('.all-to-left')
const listButton = document.querySelector('.openList')
const editButton = document.querySelector('.openEdit')

let leftList =[
]

let rightList =[
    {id: "", checked: false, title: "Dashboard"},
    {id: "1.1", checked: false, title: "Application Parameters"},
    {id: "1.2a", checked: false, title: "Portfolios"},
    {id: "1.2b", checked: false, title: "Account date for portfolio"},
    {id: "1.2c", checked: false, title: "Third parties"},
    {id: "1.2d", checked: false, title: "Equivalences"},
    {id: "1.2e", checked: false, title: "Tax table"},
    {id: "1.2f", checked: false, title: "Message"},
    {id: "1.2g", checked: false, title: "Swift message parameterization"},
    {id: "1.2h", checked: false, title: "Orders status definition"},
    {id: "1.2i", checked: false, title: "Valuation Control Parameterization"},
    {id: "1.2k", checked: false, title: "Services Files"},
    {id: "1.2l", checked: false, title: "Holiday"},
    {id: "1.2m1", checked: false, title: "KYC Masterfile"},
    {id: "1.2m2", checked: false, title: "KYC Templates"},
    {id: "1.3a", checked: false, title: "Forward Interest Rates"},
    {id: "1.3b", checked: false, title: "Ex rate historical"},
    {id: "1.4a", checked: false, title: "Historical By Group"},
    {id: "1.4b", checked: false, title: "Industry Code"},
    {id: "1.4c", checked: false, title: "SFO Master"},
    {id: "1.4d", checked: false, title: "SFO Pricing"},
    {id: "1.4e", checked: false, title: "SFO Template"},
    {id: "1.5a", checked: false, title: "Account Definition"},
    {id: "1.5b", checked: false, title: "Bank Commissions"},
    {id: "1.5c", checked: false, title: "Cash Interest"},
    {id: "1.5d", checked: false, title: "Debit Credit Template"},
    {id: "1.5e", checked: false, title: "Performance param"},
    {id: "1.6", checked: false, title: "Valuation Model Definition"},
    {id: "2.1", checked: false, title: "Deal list"},
    {id: "2.2", checked: false, title: "Interest Calculation"},
    {id: "2.3", checked: false, title: "Position Tracking"},
    {id: "2.4", checked: false, title: "Ledger Account"},
    {id: "2.5", checked: false, title: "Ibor position"},
    {id: "2.6a", checked: false, title: "Dividend Announcement"},
    {id: "2.6b", checked: false, title: "Corporate action setup"},
    {id: "2.6c", checked: false, title: "Corporate action transaction"},
    {id: "2.7", checked: false, title: "Debit Credit List"},
    {id: "2.8", checked: false, title: "Maturity List"},
    {id: "2.9a", checked: false, title: "Group order"},
    {id: "2.9b", checked: false, title: "Future order"},
    {id: "2.9c", checked: false, title: "Rebalancing Order"},
    {id: "2.9d", checked: false, title: "Bulk Order"},
    {id: "2.9e", checked: false, title: "Executed order"},
    {id: "2.10", checked: false, title: "Fix deal list"},
    {id: "2.11", checked: false, title: "Year end closing"},
    {id: "3.1", checked: false, title: "Invoice Reporting"},
    {id: "3.2a", checked: false, title: "Cash flow"},
    {id: "3.3", checked: false, title: "Reconciliation reports"},
    {id: "3.4", checked: false, title: "Valuation Detail"},
    {id: "3.5", checked: false, title: "Report interest"},
    {id: "3.6", checked: false, title: "Nantissement Report"},
    {id: "3.7", checked: false, title: "Valuation Performance"},
    {id: "3.8", checked: false, title: "Valuation Process"},
    {id: "3.9", checked: false, title: "Transaction Report"},
    {id: "3.10", checked: false, title: "Tax Reporting"},
    {id: "3.11", checked: false, title: "Performance"},
    {id: "3.12", checked: false, title: "Portfolio overview"},
    {id: "3.13", checked: false, title: "Dynamic Report"},
    {id: "4.1", checked: false, title: "User Definition"},
    {id: "4.2", checked: false, title: "MIFID Parameterization"},
    {id: "4.3", checked: false, title: "Audit Trial Check"},
    {id: "4.4", checked: false, title: "Profiles"},
    {id: "4.5", checked: false, title: "User languages definition"},
    {id: "4.6a", checked: false, title: "Process Scheduler"},
    {id: "4.6b", checked: false, title: "Manage Process"},
    {id: "4.6c", checked: false, title: "Process Manual"},
    {id: "4.6d", checked: false, title: "Process Stat"},
    {id: "4.7", checked: false, title: "Upload Services"},
    {id: "5.1", checked: false, title: "Orders Recovery"},
    {id: "5.2", checked: false, title: "Migration Parameter"},
    {id: "5.3a", checked: false, title: "Tools"},
    {id: "5.4a", checked: false, title: "Service log"},
    {id: "5.4b", checked: false, title: "Parameters"},
    {id: "5.5a", checked: false, title: "Migration processing"},
    {id: "5.5b", checked: false, title: "Accounting link"},
    {id: "5.5c", checked: false, title: "Operation codes"},
    {id: "5.5d", checked: false, title: "Data Management"},
    {id: "5.5e", checked: false, title: "Cost amount in currency"},
    {id: "5.5f", checked: false, title: "Migration manual update"},
    {id: "5.6", checked: false, title: "Interface log"},
    {id: "6.1", checked: false, title: "Rule Builder"},
    {id: "6.2", checked: false, title: "Investment Restrictions"},
]

window.onload = function () {
    if (localStorage.getItem("key") == null) {
        localStorage.setItem("key", "first")
        saveLocalStorage()
        renderDom(leftList, rightList)
        registerEvents()
    } else {
        rightList = []
        leftList = []
        rightList = JSON.parse(localStorage.getItem("rightList"))
        leftList = JSON.parse(localStorage.getItem("leftList"))
        renderDom(leftList, rightList)
        registerEvents()
    }
}

function saveLocalStorage() {
    localStorage.setItem("rightList", JSON.stringify(rightList))
    localStorage.setItem("leftList", JSON.stringify(leftList))
    rightList = []
    leftList = []
    rightList = JSON.parse(localStorage.getItem("rightList"))
    leftList = JSON.parse(localStorage.getItem("leftList"))
}

function renderDom(leftListToRender, rightListToRender){
    leftListToRender.forEach( (item) => {
        leftSilde.innerHTML += `<div class="box box-left">
           
            <input type="checkbox" class="input-box" id="${item.id}" />
            <lable for="${item.id}">${item.title}</lable>
        </div>`
    })
    rightListToRender.forEach((item) =>{
        rightSlide.innerHTML += `<div class="box box-right">
        
        <input type="checkbox" class="input-box" id="${item.id}" />
        <lable for="${item.id}">${item.title}</lable>
    </div>`
        rightSlide1.innerHTML +=  `<li class="box-right">
        <a href="http://localhost:7003/pms/faces/MainMenu?target=${item.id}" target="_blank">${item.title}</a>
    </li>`
    })
}
function clearDom() {
    document.querySelectorAll(".slide").forEach((e1)=>{
        e1.innerHTML=""
    })
    document.querySelectorAll(".right-slide-1").forEach((e1)=>{
        e1.innerHTML=""
    })
}

function registerEvents(){

    checkedToRightButton.addEventListener('click', (e)=> {
        e.preventDefault()
        let leftSildeItems = document.querySelectorAll('.box-left')
        leftSildeItems.forEach((item) => {
            if(item.firstElementChild.checked){
                leftList=leftList.filter(e =>e.id != item.firstElementChild.id.toString())
                rightList.push({id: item.firstElementChild.id, checked: false, title:item.lastElementChild.textContent})
                rightSlide.appendChild(item)
                item.firstElementChild.checked=false
            }
        })
        clearDom()
        saveLocalStorage()
        renderDom(leftList, rightList)
    })

    allToRightButton.addEventListener('click', (e) => {
        e.preventDefault()
        let leftSildeItems = document.querySelectorAll(".box-left")
        leftSildeItems.forEach((item) => {
            leftList=leftList.filter(e =>e.id != item.firstElementChild.id.toString())
            rightList.push({id: item.firstElementChild.id,checked:false, title:item.lastElementChild.textContent})
            rightSlide.appendChild(item)
            item.firstElementChild.checked=false
        })
        clearDom()
        saveLocalStorage()
        renderDom(leftList, rightList)
    })

    checkedToLeftButton.addEventListener('click', (e) => {
        e.preventDefault()
        let rightSlideItems = document.querySelectorAll('.box-right')
        rightSlideItems.forEach((item) => {
            if(item.firstElementChild.checked){
                rightList=rightList.filter(e =>e.id != item.firstElementChild.id.toString())
                leftList.push({id: item.firstElementChild.id,checked:false, title:item.lastElementChild.textContent})
                leftSilde.appendChild(item)
                item.firstElementChild.checked=false
            }
        })
        clearDom()
        saveLocalStorage()
        renderDom(leftList, rightList)
    })

    allToLeftButton.addEventListener('click', (e) => {
        e.preventDefault()
        let rightSlideItems = document.querySelectorAll(".box")
        rightSlideItems.forEach((item) => {
            console.log(item)
            rightList = rightList.filter(e => e.id != item.firstElementChild.id.toString())
            leftList.push({id: item.firstElementChild.id,checked:false, title:item.lastElementChild.textContent})
            leftSilde.appendChild(item)
            item.firstElementChild.checked=false
        })
        clearDom()
        saveLocalStorage()
        renderDom(leftList, rightList)
    })

    listButton.addEventListener('click', (e) => {
        document.getElementById("mEdit").style.display = "block";
        document.getElementById("mList").style.display = "none";
        document.getElementById("list").style.display = "block";
        document.getElementById("edit").style.display = "none";
        // clearDom()
        // saveLocalStorage()
        // renderDom(leftList, rightList)
    })

    editButton.addEventListener('click', (e) => {
        document.getElementById("mEdit").style.display = "none";
        document.getElementById("mList").style.display = "block";
        document.getElementById("list").style.display = "none";
        document.getElementById("edit").style.display = "block";
        // clearDom()
        // saveLocalStorage()
        // renderDom(leftList, rightList)
    })
}